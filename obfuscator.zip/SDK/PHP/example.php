<?php

////////////////////////////////////////////////////////////////////////////////
//
// Obfuscator Web API usage example
//
// Version        : v1.0
// Language       : PHP
// Author         : Bartosz Wójcik
// Web page       : https://www.pelock.com
//
////////////////////////////////////////////////////////////////////////////////

// include main library
include ("obfuscator.php");

//
// setup parameters
//
$params = array();

//
// activation code, you can leave it empty for demo version, but keep in
// mind that there are many limitations in demo version)
//
$params["code"] = "";

//
// API command to execute
//
// "obfuscate" - obfuscate source code
// "login" - checks current activation code
//
// Return values
//
// $result["error"] [out]
//   Error code. 
//
// $result["output"] [out, optional]
//   Obfuscated source code.
//
// $result["demo"] [out]
//   Are we running in full or demo mode.
//
// $result["credits_left"] [out]
//   Usage credits left for the provided activation code.
//
// $result["expired"] [out, optional]
//   If set to true it means our activation code has expired (it was the last run).
//
// $result["string_limit"] [out, optional]
//   Source code size limit for full & demo version.
//
// $result["junks_min"] [out, optional]
//   Min. number of junks for the $params["junks_min"] parameter.
//
// $result["junks_max"] [out, optional]
//   Max. number of junks for the $params["junks_max"] parameter.
//
// $result["com_min"] [out, optional]
//   Min. number of junks for the $params["com_min"] parameter.
//
// $result["com_max"] [out, optional]
//   Max. number of junks for the $params["com_max"] parameter.
//
// $result["mutation_passes_min"] [out, optional]
//   Min. number of junks for the $params["mutation_passes"] parameter.
//
// $result["mutation_passes_max"] [out, optional]
//   Min. number of junks for the $params["mutation_passes"] parameter.
//
$params["command"] = "obfuscate";

//
// source code compression
//
// if you set it to true, you need to compress input source code
//
// $params["source"] = @base64_encode(@gzcompress($string, 9)
//
// and after obfuscation you need to decompress obfuscated source code
//
// $decompressed = @gzuncompress(@base64_decode($result["output"]));
//
$params["compression"] = false;
//$params["compression"] = true;

//
// input source code in MASM format
//
$source = 'return_true proc uses esi edi ebx
xor ecx,ecx
mov eax,1
ret
return_true endp';

if ($params["compression"] == false)
{
	$params["source"] = $source;
}
else
{
	$params["source"] = @base64_encode(@gzcompress($source, 9));
}

//
// change code execution flow to nonlinear path.
//
$params["code_mixup"] = "1";

//
// mutate original opcodes into series of other equivalent instructions.
//
$params["change_logic"] = "1";

//
// Mutation passes for the $params["change_logic"] obfuscation method.
//
$params["mutation_passes"] = "1";

//
// Hide procedure calls by replacing call instructions with opaque predicates (WinApi etc.).
//
$params["expand_calls"] = "1";

//
// Resolve WinApi constants to numerical values (so it can be obfuscated as an unsigned integer values).
//
$params["resolve_const"] = "1";

//
// Assume WinApi calling convention (EAX, ECX & EDX registers can be changed before call).
//
$params["assume_stdcall"] = "1";

//
// Insert fake jumps (jx + jnx).
//
$params["insert_fake_jumps"] = "1";

//
// Insert register jumps (jmp reg32).
//
$params["insert_reg_jumps"] = "1";

//
// Prefix junk opcodes with rep/repxx.
//
$params["rep_prefix"] = "1";

//
// Insert junk SEH handlers (invoke misguiding exceptions).
//
$params["insert_seh"] = "1";

//
// Insert COM like jumps (jmp dword ptr [imm32 + rnd]).
//
$params["insert_com_jumps"] = "1";

//
// Min. number of COM like jumps.
//
$params["com_min"] = "1";

//
// Max. number of COM like jumps.
//
$params["com_max"] = "1";

//
// Insert junk instructions between original instructions
//
$params["insert_junks"] = "1";

//
// Min. number of junks per command.
//
$params["junks_min"] = "1";

//
// Max. number of junks per command.
//
$params["junks_max"] = "1";

//
// Insert fake commands (add reg32,1 + sub reg32,1 etc.).
//
$params["fake_cmd"] = "1";

//
// Insert fake 32 bit commands.
//
$params["fake_cmd_32"] = "1";

//
// Insert fake 16 bit commands.
//
$params["fake_cmd_16"] = "1";

//
// Insert fake 8 bit commands.
//
$params["fake_cmd_8"] = "1";

//
// obfuscate source code
//
$result = obfuscate($params);

if ($result != false)
{
	if ($result["error"] == ERROR_SUCCESS)
	{
		// if compression was enabled, we need to
		// decompress the output source code
		if ($params["compression"] == true)
		{
			$source = @gzuncompress(@base64_decode($result["output"]));
		}
		else
		{
			$source = $result["output"];
		}

		// display obfuscated source code
		echo "<pre>".$source."</pre>";

		// display number of credits left
		echo "<p>You have {$result['credits_left']} credits left.</p>";

		// activation code has expired, notify user
		if ($result["expired"] == true)
		{
			echo "<p>Your activation code has expired!</p>";
		}
	}
	else
	{
		echo "An error occurred (code ".$result["error"].")";
	}
}
else
{
	echo "Cannot connect to the API interface!";
}

?>