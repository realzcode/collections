<?php

////////////////////////////////////////////////////////////////////////////////
//
// Obfuscator Web API library
//
// Version        : v1.0
// Language       : PHP
// Author         : Bartosz Wójcik
// Web page       : https://www.pelock.com
//
////////////////////////////////////////////////////////////////////////////////

// web API interface URL
define("OBFUSCATOR_API_URL", "https://www.pelock.com/api/obfuscator/v1");

// everything went fine
define("ERROR_SUCCESS", 0);

// obfuscator didn't find any procedures to obfuscate.
define("ERROR_NOPROC", 1);

// you didn't specify any obfuscation options.
define("ERROR_NOFLAGS", 2);

// malformed source code, check the syntax.
define("ERROR_INPUT", 3);

// source code size is too big. Most probably you hit the demo mode limitation.
define("ERROR_INPUT_SIZE", 4);

//
// main obfuscation function
//
// $params_array     - an array with encryption parameters (see example.php
//                     for the complete list of parameters)
// $use_curl_library - use cURL library to send a POST request, please note,
//                     that the cURL library might not be available everywhere
//
function obfuscate($params_array, $use_curl_library = false)
{
	// detect cURL library and disable it if it's not found
	if (function_exists('curl_init') == false && $use_curl_library == true)
	{
		$use_curl_library = false;
	}

	// send a request to the API interface
	if ($use_curl_library == false)
	{
		$result = post_request(OBFUSCATOR_API_URL, $params_array);
	}
	else
	{
		$result = post_request_curl(OBFUSCATOR_API_URL, $params_array);
	}

	// decode result from the JSON format into associative array
	if ($result != false)
	{
		$result = json_decode($result, true);
	}

	return $result;
}

//
// send a POST request
//
function post_request($url, $data)
{
	$params = array('http' => array(
		'method' => 'POST',
		'content' => http_build_query($data)
		));

	$ctx = stream_context_create($params);

	$fp = @fopen($url, 'rb', false, $ctx);

	if (!$fp)
	{
		return false;
	}

	//$meta = stream_get_meta_data($fp);
	//var_dump($meta['wrapper_data']);
	//die("exit");

	$response = @stream_get_contents($fp);

	return $response;
}

//
// send a POST request using cURL library
//
function post_request_curl($url, $data)
{
	$ch = curl_init();

	$fields_string = "";

	foreach($data as $key => $value)
	{
		$fields_string .= $key.'='.$value.'&';
	}

	$fields_string = rtrim($fields_string, '&');

	// url
	curl_setopt($ch, CURLOPT_URL, $url);

	// number of parameters
	curl_setopt($ch, CURLOPT_POST, count($data));

	// POST parameters
	curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);

	// user agent
	curl_setopt($ch, CURLOPT_USERAGENT, "Obfuscator Web API Client v1.0");

	// return only result
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	// query URL
	$result = curl_exec($ch);

	// close session
	curl_close($ch);

	// return result
	return $result;
}

?>