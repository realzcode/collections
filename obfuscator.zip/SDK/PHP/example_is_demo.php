<?php

////////////////////////////////////////////////////////////////////////////////
//
// Obfuscator Web API usage example
//
// Version        : v1.0
// Language       : PHP
// Author         : Bartosz Wójcik
// Web page       : https://www.pelock.com
//
////////////////////////////////////////////////////////////////////////////////

// include main library
include ("obfuscator.php");

//
// setup parameters
//
$params = array();

//
// activation code, you can leave it empty for demo version, but keep in
// mind that there are many limitations in demo version)
//
$params["code"] = "";

//
// API command to execute
//
// "obfuscate" - obfuscate source code
// "login" - checks current activation code
//
// Return values
//
// $result["error"] [out]
//   Error code. 
//
// $result["output"] [out, optional]
//   Obfuscated source code.
//
// $result["demo"] [out]
//   Are we running in full or demo mode.
//
// $result["credits_left"] [out]
//   Usage credits left for the provided activation code.
//
// $result["expired"] [out, optional]
//   If set to true it means our activation code has expired (it was the last run).
//
// $result["string_limit"] [out, optional]
//   Source code size limit for full & demo version.
//
// $result["junks_min"] [out, optional]
//   Min. number of junks for the $params["junks_min"] parameter.
//
// $result["junks_max"] [out, optional]
//   Max. number of junks for the $params["junks_max"] parameter.
//
// $result["com_min"] [out, optional]
//   Min. number of junks for the $params["com_min"] parameter.
//
// $result["com_max"] [out, optional]
//   Max. number of junks for the $params["com_max"] parameter.
//
// $result["mutation_passes_min"] [out, optional]
//   Min. number of junks for the $params["mutation_passes"] parameter.
//
// $result["mutation_passes_max"] [out, optional]
//   Min. number of junks for the $params["mutation_passes"] parameter.
//
$params["command"] = "login";

//
// execute API command
//
$result = obfuscate($params);

if ($result != false)
{
	if ($result["demo"] == true)
	{
		echo "<p>You are running in DEMO mode</p>";
	}
	else
	{
		echo "<p>You are running in FULL mode</p>";

		// display number of credits left
		echo "<p>You have {$result['credits_left']} credits left.</p>";
	}

	echo "<p>Source code max. length {$result['string_limit']} characters</p>";
}
else
{
	echo "Cannot connect to the API interface!";
}

?>