
Obfuscator v2.3
~~~~~~~~~~~~~~~
Obfuscator is a tool to modify x86 assembler source code in this way to make
an analysis of compiled code very difficult

It is an unusual tool and the target audience is quite small, but if you're
writing in assembler and you want to protect your work from decompilation
or just to make it as hard as it's possible to analyze, you might want to try it.

Obfuscatora features:

     * MASM syntax only, processing of @@ labels, detection of local variables,
       constant equ values, and numbers in different formats (hex, dec)

     * changing code execution flow (non linear code path) - it's usefull
       against all kinds of debuggers, analysis of such code is very "unpleasant"

     * mutation of original instructions into series of other equivalent
       opcodes - obfuscator can mutate both arithmetic and logical opcodes

     * hiding of direct calls to functions (including WinApi calls)

     * inserting garbage opcodes between real instructions (so called "junks")

     * inserting fake instructions between real ones, 32/16/8 opcodes are generated

     * inserting fake exceptions between real code (SEH frames)

     * resolving of WinApi constants to numerical values (so it can be obfuscated)

What's new
~~~~~~~~~~
v2.3
* many internal bug-fixes
* all executable files double signed for Windows XP, Vista, 7, 8, 8.1 (SHA1)
  and Windows 10 (SHA-256)
* PHP SDK
* new icons

v2.2
* command line utility added (run without any params to see all available options)

v2.1
* connection is now encrypted by default (HTTPS protocol)

v2.0
* entire code base rewritten
* resolving of WinApi constants to numerical values (so it can be obfuscated too)
* improved code mutations
* better entire input code analysis
* improved constants detection
* rewritten math operations & mutations (especially binary rotations)
* fake SEH frames handling extended
* client code rewritten in .NET with many new usability features

v1.0 - first public release

How to buy credits?
~~~~~~~~~~~~~~~~~~~
Pricing is available at https://www.pelock.com/products/obfuscator/buy

System requirements
~~~~~~~~~~~~~~~~~~~
- Pentium CPU
- 256 MB RAM
- at Internet connection
- .NET Framework v2.0 or v3.5

Contact information
~~~~~~~~~~~~~~~~~~~
Name    : Bartosz W�jcik
E-Mail  : obfuscator@pelock.com
Website : https://www.pelock.com
