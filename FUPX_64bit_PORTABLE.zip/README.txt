Name: FUPX
Version: 3.2
License: Freeware
Release date: 2022.11.09
Author: Jacek Pazera
Web page: https://www.pazera-software.com/products/free-upx/
Help page: https://www.pazera-software.com/guide/fupx/
-----------------------------------------------
UPX authors: Markus Oberhumer, Laszlo Molnar & John Reiser
UPX page: https://upx.github.io/

////////////////////////////////////////////////////////////////////////////////

LICENSE

This program (FUPX) is completely free. You can use it without any restrictions, also for commercial purposes.

////////////////////////////////////////////////////////////////////////////////

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY or SUPPORT. YOU USE IT AT YOUR OWN RISK.

////////////////////////////////////////////////////////////////////////////////
